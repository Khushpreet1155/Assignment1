<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View User</title>
    <link rel="stylesheet" href="../styles/styles.css">
    <!-- Link to Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<body>
<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">

    <a class="navbar-brand" href="../index.html" style="color: cadetblue ">Interest Web</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item active">
                <a class="nav-link" href="../index.html">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="add_content.php">Add Content</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_content.php">View Content</a>
            </li>
        </ul>
    </div>
</nav>

<h4 style="padding: 20px">View User Information</h4>
<!-- Display Content -->
<div class="userContainer mt-4 ">
    <?php
    include '../process/process_view_content.php';?>

</div>

<!-- Footer -->
<footer class="bg-light text-center py-3">
    © 2024 Interest Web
</footer>
</body>
</html>
