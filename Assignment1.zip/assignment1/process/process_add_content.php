<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "subscriber_portal";
// Create a connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $interest_id = $_POST['interest_id'];


    // Validate form data
    if (empty($firstname) || empty($lastname) || empty($email) || empty($interest_id)) {
        echo "Please fill all the fields.";
    } else {

        // Insert the content into your database table
        $sql = "INSERT INTO users (first_name, last_name, email, interest_id) VALUES ('$firstname', '$lastname', '$email', '$interest_id')";

        if (mysqli_query($conn, $sql)) {
            echo '<script>alert("Operation successful.");</script>';
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }
}

mysqli_close($conn);
?>
