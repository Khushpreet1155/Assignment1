<?php

// Connect to your database
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "subscriber_portal";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from your database table
$sql = "SELECT * FROM interests";
$result = $conn->query($sql);

// Store the fetched data in an array
$data = array();
if ($result->num_rows > 0) {
    while($interest = $result->fetch_assoc()) {
        echo '<option value="' . $interest['interest_id'] . '">' . $interest['interest_name'] . '</option>';
    }
}

// Close the connection
$conn->close();
?>
