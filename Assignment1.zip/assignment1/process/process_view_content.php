<?php

// Connect to your database
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "subscriber_portal";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from your database table
$sql = "SELECT * FROM `users` JOIN interests ON users.interest_id = interests.interest_id;";
$result = $conn->query($sql);

// Store the fetched data in an array
$data = array();
if ($result->num_rows > 0) {
    while($user = $result->fetch_assoc()) {

        echo "User ID: " . $user["user_id"] . "<br>";
        echo "First Name: " . $user["first_name"] . "<br>";
        echo "Last Name: " . $user["last_name"] . "<br>";
        echo "Email: " . $user["email"] . "<br>";
        echo "Interest: " . $user["interest_name"] . "<br><br>";

    }
}

// Close the connection
$conn->close();
?>
